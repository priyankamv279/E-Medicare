package com.medicare;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.medicare.user.AuthenticationStatus;
import com.medicare.user.User;
import com.medicare.user.UserRepository;
import com.medicare.user.UserService;

@RunWith(Suite.class)
@SuiteClasses({})
@SpringBootTest
class UserSignupSigninTest {

	@Autowired
	UserService userService;
	
	@Autowired
	UserRepository userRepository;
	
	
	@Test
	@DisplayName("SigUp with valid details")
	public void signUpTest(){
		User user = new User();
		user.setFirst_name("First2");
		user.setLast_name("UserTest1");
		user.setMobile_no("9876543277");
		user.setAge(25);
		user.setUsername("firstusertest@example.com");
		user.setPassword("Password@124");
		user.setGender("Male");
		userService.insertUser(user);
	}
	
	@Test
	@DisplayName("SigIn with valid details")
	public void signInTest(){
		String username = "firstusertest@email.com";
		String password = "Password@123";
		
		AuthenticationStatus res = userService.getStatus(username, password);
	}

}
